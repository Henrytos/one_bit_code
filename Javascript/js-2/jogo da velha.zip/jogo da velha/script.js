const game=['','','','','','','','','']
const turnPlayer = document.getElementById('turn')

const cell = document.querySelectorAll('.cell')
cell.forEach(function(element,indice){
        element.addEventListener('click',function(ev){
            
                console.log('vez do jogador 1')
                if(element.innerText===''){
                        ev.currentTarget.innerText='x'
                        game.splice(element.id,1,'x')
                        console.log(game)
                    if((game[0]=='x'&&game[1]=='x'&&game[2]=='x')||
                    (game[3]=='x'&&game[4]=='x'&&game[5]=='x')||
                    (game[6]=='x'&&game[7]=='x'&&game[8]=='x')||
                    (game[0]=='x'&&game[3]=='x'&&game[6]=='x')||
                    (game[1]=='x'&&game[4]=='x'&&game[7]=='x')||
                    (game[2]=='x'&&game[5]=='x'&&game[8]=='x')||
                    (game[2]=='x'&&game[4]=='x'&&game[6]=='x')||
                    (game[0]=='x'&&game[4]=='x'&&game[8]=='x')
                    ){
                     
                        console.log('X venceu')
                        alert('Jogador X Venceu')
                        removeS()
                        
                    }
                
                    }
            })
})

document.getElementById('btn').addEventListener('click', function (ev) {
    const player1 = document.getElementById('player1').value
    const player2 = document.getElementById('player2').value
    const camp = document.getElementById('players')
    const span = document.getElementById('span')
    span.remove()
    // O nome do jogador da vez deve ser mostrado na tela e alterado a medida que os turnos vão se alternando;
    const h2 = document.createElement('h2')
    h2.innerText = player1 + ' X ' + player2
    camp.appendChild(h2)
    turnPlayer.innerText = 'é vez do jogador:' + player1
    return

})
document.getElementById('reset').addEventListener('click',removeS)
function  removeS(){
    cell.forEach(function(element){
        element.innerText=''
      
    })
   for (let index = 0; index < game.length; index++) {
           game[index]=''
   }
}